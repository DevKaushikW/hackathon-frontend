import { useEffect } from 'react';
import oauthService from "../../../services/oauthService"
import profileData from '../../../data/profileData.json';

const useProfileEffects = (
  setProfile,
  setEditedName,
  setEditedEmails,
  setEditedPhones,
  setEditedLocation,
  setEditedProvider,
  setEditedRole,
  setEditedResume,
  isAddingWorkExperience
) => {
  // Initialize profile from oauthService and profileData
  useEffect(() => {
    const user = oauthService.getCurrentUser();
    if (user) {
      setProfile({
        name: user.name,
        email: user.email,
        provider: user.provider,
        id: user.id,
        role: user.role,
        username: '@avgfcgjfk',
        picture: user.picture || '',
        resume: profileData.resume || '',
        ...profileData
      });
      setEditedName(user.name);
      setEditedEmails([user.email]);
      setEditedPhones(profileData.phone ? [profileData.phone] : []);
      setEditedLocation(profileData.location || '');
      setEditedProvider(user.provider || '');
      setEditedRole(user.role || '');
      setEditedResume(profileData.resume || null);
    }
  }, []);

  // // Lock background scroll when modal is open
  // useEffect(() => {
  //   document.body.style.overflow = isAddingWorkExperience ? 'hidden' : 'auto';
  // }, [isAddingWorkExperience]);
};

export default useProfileEffects;
