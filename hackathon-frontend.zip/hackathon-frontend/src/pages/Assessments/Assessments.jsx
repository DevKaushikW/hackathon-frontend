import React, { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import submissions from '../../data/submissionsData.json';

const Assessments = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const submissionsPerPage = 10;

  // Calculate total pages
  const totalPages = Math.ceil(submissions.length / submissionsPerPage);

  // Get current page submissions
  const indexOfLastSubmission = currentPage * submissionsPerPage;
  const indexOfFirstSubmission = indexOfLastSubmission - submissionsPerPage;
  const currentSubmissions = submissions.slice(indexOfFirstSubmission, indexOfLastSubmission);

  // Generate page numbers for pagination
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  const handleClick = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div style={{backgroud: "#9be0e4ff"}}>
      <Header title="Dashboard" />
      <div style={{ padding: '50px', maxWidth: '900px', margin: '0 auto' , textAlign: 'center'}}>
        <p><h1>Submissions</h1></p>
        <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '0 10px', marginTop: '20px', border: '1px solid #e1e4e8', borderRadius: '6px', backgroundColor: '#fff' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid #e1e4e8', backgroundColor: '#f6f8fa' }}>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Problem</th>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Language</th>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Time</th>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Result</th>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Score</th>
              <th style={{ textAlign: 'left', padding: '12px 16px', color: '#24292e', fontWeight: '600', fontSize: '14px' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {currentSubmissions.map((submission, index) => (
              <tr key={index} style={{ backgroundColor: '#fff', boxShadow: '0 1px 3px rgb(27 31 35 / 12%)', borderRadius: '6px', marginBottom: '10px' }}>
                <td style={{ padding: '12px 16px', color: '#0366d6', fontSize: '14px' }}>
                  <a href="#" style={{ color: '#0366d6', textDecoration: 'none' }}>
                    {submission.problem}
                  </a>
                </td>
                <td style={{ padding: '12px 16px', color: '#586069', fontSize: '14px' }}>{submission.language}</td>
                <td style={{ padding: '12px 16px', color: '#586069', fontSize: '14px' }}>{submission.time}</td>
                <td style={{ padding: '12px 16px', color: '#28a745', fontWeight: '600', fontSize: '14px' }}>{submission.result}</td>
                <td style={{ padding: '12px 16px', color: '#586069', fontSize: '14px' }}>{submission.score}</td>
                <td style={{ padding: '12px 16px' }}>
                  <button
                    style={{
                      padding: '6px 12px',
                      border: '1px solid #d1d5da',
                      backgroundColor: 'white',
                      color: '#24292e',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      fontSize: '14px',
                      fontWeight: '600',
                      lineHeight: '20px',
                      transition: 'background-color 0.2s ease',
                    }}
                    onClick={() => alert(`Viewing results for ${submission.problem}`)}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f6f8fa'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = 'white'}
                  >
                    View results
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px', gap: '8px', fontSize: '14px' }}>
          <button
            onClick={() => currentPage > 1 && handleClick(currentPage - 1)}
            disabled={currentPage === 1}
            style={{
              border: 'none',
              background: 'none',
              cursor: currentPage === 1 ? 'default' : 'pointer',
              color: '#24292e',
              fontWeight: '600',
              fontSize: '18px',
              userSelect: 'none',
            }}
          >
          </button>
          {pageNumbers.map((number, idx) => {
            if (number === 1 || number === totalPages || (number >= currentPage - 2 && number <= currentPage + 2)) {
              return (
                <button
                  key={number}
                  onClick={() => handleClick(number)}
                  style={{
                    border: 'none',
                    background: 'none',
                    cursor: 'pointer',
                    color: number === currentPage ? '#2ea44f' : '#24292e',
                    fontWeight: number === currentPage ? '700' : '600',
                    borderBottom: number === currentPage ? '2px solid #2ea44f' : 'none',
                    padding: '0 6px',
                    userSelect: 'none',
                  }}
                >
                  {number}
                </button>
              );
            } else if (
              (number === currentPage - 3 && number > 1) ||
              (number === currentPage + 3 && number < totalPages)
            ) {
              return <span key={number} style={{ padding: '0 6px' }}>...</span>;
            } else {
              return null;
            }
          })}
          <button
            onClick={() => currentPage < totalPages && handleClick(currentPage + 1)}
            disabled={currentPage === totalPages}
            style={{
              border: 'none',
              background: 'none',
              cursor: currentPage === totalPages ? 'default' : 'pointer',
              color: '#24292e',
              fontWeight: '600',
              fontSize: '18px',
              userSelect: 'none',
            }}
          >
          </button>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Assessments;
