import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Card, CardContent, Typography, Radio, RadioGroup, FormControlLabel, Button } from "@mui/material";
import csharpQuestionsData from "../../data/csharpQuestions.json";

const Quiz = () => {
  const location = useLocation();
  const difficulty = location.state?.difficulty ?? 5;

  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState("");
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);

  useEffect(() => {
    // Filter questions based on difficulty rules:
    // At least 5 questions from selected difficulty
    // No questions from difficulty above selected
    // Remaining questions randomly from allowed difficulties below selected

    const allQuestions = csharpQuestionsData.questions;

    // Get questions from selected difficulty
    const selectedDifficultyQuestions = allQuestions[difficulty] || [];

    // Get allowed difficulties below selected difficulty
    const allowedDifficulties = Object.keys(allQuestions)
      .map(Number)
      .filter((d) => d < difficulty)
      .sort((a, b) => b - a); // descending order

    // Collect questions from allowed difficulties
    let otherQuestions = [];
    allowedDifficulties.forEach((d) => {
      otherQuestions = otherQuestions.concat(allQuestions[d] || []);
    });

    // Shuffle otherQuestions
    otherQuestions = otherQuestions.sort(() => Math.random() - 0.5);

    // Take 5 from selected difficulty and 5 from otherQuestions
    const quizQuestions = [
      ...selectedDifficultyQuestions.slice(0, 5),
      ...otherQuestions.slice(0, 5),
    ];

    // Shuffle final quizQuestions
    setQuestions(quizQuestions.sort(() => Math.random() - 0.5));
  }, [difficulty]);

  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
  };

  const handleNext = () => {
    if (selectedOption === questions[currentIndex].answer) {
      setScore(score + 1);
    }
    setSelectedOption("");
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setShowScore(true);
    }
  };

  const handleRestart = () => {
    setScore(0);
    setCurrentIndex(0);
    setSelectedOption("");
    setShowScore(false);
  };

  if (questions.length === 0) {
    return (
      <div>
        <Header />
        <Typography>Loading questions...</Typography>
        <Footer />
      </div>
    );
  }

  return (
    <div style={{ minHeight: "calc(100vh - 64px - 64px)", display: "flex", flexDirection: "column" }}>
      <main style={{ flex: 1, display: "flex", justifyContent: "center", alignItems: "center" }}>
        <Card sx={{ maxWidth: 700, width: "100%", padding: 3 }}>
          <CardContent>
            {showScore ? (
              <div>
                <Typography variant="h5" gutterBottom>
                  Your Score: {score} / {questions.length}
                </Typography>
                <Button variant="contained" color="primary" onClick={handleRestart}>
                  Restart Quiz
                </Button>
              </div>
            ) : (
              <div>
                <Typography variant="h6" gutterBottom>
                  Question {currentIndex + 1} of {questions.length}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  {questions[currentIndex].question}
                </Typography>
                <RadioGroup value={selectedOption} onChange={handleOptionChange}>
                  {questions[currentIndex].options.map((option, idx) => (
                    <FormControlLabel key={idx} value={option} control={<Radio />} label={option} />
                  ))}
                </RadioGroup>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleNext}
                  disabled={selectedOption === ""}
                  sx={{ mt: 2 }}
                >
                  {currentIndex + 1 === questions.length ? "Finish" : "Next"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
};

export default Quiz;
