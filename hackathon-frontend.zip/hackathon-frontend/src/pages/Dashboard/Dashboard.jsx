import React from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();

  const courses = [
    { name: 'C#', progress: 29, note: '25 points to next star' },
    { name: 'SQL', progress: 14, note: 'Get to 35 points to unlock this badge' },
    { name: 'Java', progress: 8, note: '92 points to gold badge' }
  ];

  const assessments = ['Cloud Foundation'];

  const cardStyle = {
    backgroundColor: '#fcfafaff',
    color: '#121312ff',
    border: '2px solid #90ee90',
    borderRadius: '10px',
    padding: '20px',
    boxShadow: '0 8px 16px rgba(57, 255, 20, 0.3)',
    height: '180px',
    textAlign: 'center',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    transition: 'transform 0.3s ease',
    cursor: 'pointer'
  };

  return (

    <div style={{
      background: "#9be0e4ff",
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      minWidth: '1250px'
    }}>

      <Header title="My Dashboard" showUser={true} />


      <div style={{
        flex: 1,
        padding: '80px 20px 60px',
        maxWidth: '1000px',
        margin: '0 auto'
      }}>

        {/* Courses Section */}
        <section style={{ marginBottom: '40px' }}>
          <h2 style={{ color: '#090909ff' }}>Courses</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '20px'
          }}>
            {courses.map((course, index) => (
              <div
                key={index}
                style={cardStyle}
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-5px)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
                onClick={() => navigate('/StartQuiz')}
              >
                <h3>{course.name}</h3>
                <div style={{
                  backgroundColor: '#fcfbfbff',
                  borderRadius: '5px',
                  overflow: 'hidden',
                  height: '20px',
                  marginBottom: '10px'
                }}>
                  <div style={{
                    width: `${course.progress}%`,
                    backgroundColor: '#308521ff',
                    height: '100%'
                  }}></div>
                </div>
                <p style={{ fontSize: '14px' }}>{course.note}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Assessments Section */}
        <section>
          <h2 style={{ color: '#000000ff' }}>Upcoming Assessments</h2>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '20px'
          }}>
            {assessments.length > 0 ? (
              assessments.map((assessment, index) => (
                <div
                  key={index}
                  style={cardStyle}
                  onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-5px)')}
                  onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
                  onClick={() => navigate('/StartQuiz')}
                >
                  <h3>{assessment}</h3>
                  <p>Assessment scheduled soon</p>
                </div>
              ))
            ) : (
              <p style={{ color: '#39FF14' }}>No upcoming assessments available.</p>
            )}
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
};

export default Dashboard;
